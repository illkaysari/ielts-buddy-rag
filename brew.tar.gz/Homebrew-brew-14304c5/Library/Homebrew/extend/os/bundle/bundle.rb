# typed: strict
# frozen_string_literal: true

require "extend/os/linux/bundle/bundle" if OS.linux?
